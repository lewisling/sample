//= require jquery.effects.blind
//= require jquery.effects.bounce
//= require jquery.effects.clip
//= require jquery.effects.core
//= require jquery.effects.drop
//= require jquery.effects.explode
//= require jquery.effects.fade
//= require jquery.effects.fold
//= require jquery.effects.highlight
//= require jquery.effects.pulsate
//= require jquery.effects.scale
//= require jquery.effects.shake
//= require jquery.effects.slide
//= require jquery.effects.transfer
;
